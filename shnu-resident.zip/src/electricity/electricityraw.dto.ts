
export class ElectricityRaw {

    room: string;

    region: string;

    price: number;

}